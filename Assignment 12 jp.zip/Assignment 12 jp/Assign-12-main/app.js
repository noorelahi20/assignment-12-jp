//chapter 1
//Qns 1

// alert("First Name");
// alert("Last Name");
// alert("Email");
// alert("Phone Number V. Password");

//qns 2
// alert ("You're learning JavaScript");


// //qns 3
// alert("Hello World")


// //Chapter 2
// //qns 1

// var firstName = "Abdullah"

// //qns 2

// var lastname;
// lastname = "Abdullah"

// //qns 3
// var teamName = "sacl tiger";
// alert("sacl tiger");

// //qns 4
// var bestMan = "John"


// //chapter 3
// //qns 1

// var caseQty;

// //qns 2
// caseQty = 144;

// //qns 3
// var num = "9";

//qns 4
// var total = caseQty + Number(num);
// console.log(total);


//qns 5
// var orderTotal;

// var merchTotal = 100;
// var shippingCharge = 10;

// orderTotal = merchTotal + shippingCharge;

// console.log(orderTotal);

//qns 6

// let number = 5;        
// number += 3;          
// console.log(number);
















